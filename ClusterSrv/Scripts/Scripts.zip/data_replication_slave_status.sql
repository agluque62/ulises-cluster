
show slave status\G;